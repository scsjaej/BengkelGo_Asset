export default function ApplicationLogo(props) {
    return (
        <div className="flex">
            {/* <img src={asset('logo.png')} alt="" /> */}
            <h1 className="mb-5 text-5xl font-bold text-info-content">Bengkel<span className='text-red-800'>Go</span></h1>
        </div>
    );
}
